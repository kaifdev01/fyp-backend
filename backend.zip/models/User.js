const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    maxlength: [50, 'Name cannot exceed 50 characters']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    validate: {
      validator: function(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      },
      message: 'Please enter a valid email'
    },
    index: true
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [8, 'Password must be at least 8 characters'],
    validate: {
      validator: function(password) {
        return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password);
      },
      message: 'Password must contain at least 8 characters with uppercase, lowercase, number and special character'
    },
    select: false
  },
  roles: [{
    type: String,
    enum: ['client', 'freelancer', 'pending']
  }],
  primaryRole: {
    type: String,
    enum: ['client', 'freelancer', 'pending'],
    required: [true, 'Primary role is required']
  },
  avatar: {
    type: String,
    default: ''
  },
  intro: {
    type: String,
    maxlength: [200, 'Intro cannot exceed 200 characters'],
    default: ''
  },
  bio: {
    type: String,
    maxlength: [1500, 'Bio cannot exceed 1500 characters'],
    default: ''
  },
  skills: [{
    type: String,
    trim: true
  }],
  location: {
    type: String,
    trim: true,
    default: ''
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  otp: {
    type: String,
    select: false
  },
  otpExpires: {
    type: Date,
    select: false
  },
  rating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  totalEarnings: {
    type: Number,
    default: 0
  },
  completedProjects: {
    type: Number,
    default: 0
  },
  companySize: {
    type: String,
    default: ''
  },
  industry: {
    type: String,
    default: ''
  },
  phone: {
    type: String,
    default: '',
    validate: {
      validator: function(phone) {
        return !phone || /^[\+]?[1-9][\d]{0,15}$/.test(phone);
      },
      message: 'Please enter a valid phone number'
    }
  },
  hourlyRate: {
    type: Number,
    default: 0
  },
  googleId: {
    type: String,
    default: null
  },
  githubId: {
    type: String,
    default: null
  },
  resetPasswordToken: {
    type: String,
    select: false
  },
  resetPasswordExpires: {
    type: Date,
    select: false
  },
  lastActivity: {
    type: Date,
    default: Date.now
  },
  profileViews: {
    type: Number,
    default: 0
  },
  weeklyProfileViews: {
    type: Number,
    default: 0
  },
  lastViewsReset: {
    type: Date,
    default: Date.now
  },
  isAvailable: {
    type: Boolean,
    default: true
  },
  portfolio: [{
    title: String,
    description: String,
    image: String,
    url: String,
    media: [{
      url: String,
      type: {
        type: String,
        enum: ['image', 'video']
      },
      name: String
    }],
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  languages: [{
    language: String,
    proficiency: {
      type: String,
      enum: ['Basic', 'Conversational', 'Fluent', 'Native']
    }
  }],
  education: [{
    school: String,
    degree: String,
    field: String,
    startYear: String,
    endYear: String,
    description: String
  }]
}, {
  timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare password method
userSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Generate JWT token
userSchema.methods.generateToken = function () {
  return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
    expiresIn: '2d' // Token expires in 2 days
  });
};

// Update last activity
userSchema.methods.updateActivity = function () {
  this.lastActivity = new Date();
  return this.save();
};

// Generate OTP
userSchema.methods.generateOTP = function () {
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  this.otp = otp;
  this.otpExpires = Date.now() + 10 * 60 * 1000; // 10 minutes
  return otp;
};

// Verify OTP
userSchema.methods.verifyOTP = function (candidateOTP) {
  return this.otp === candidateOTP && this.otpExpires > Date.now();
};

// Calculate profile completion percentage
userSchema.methods.getProfileCompletion = function () {
  const requiredFields = [
    this.name,
    this.email,
    this.bio,
    this.location,
    this.hourlyRate > 0,
    this.skills?.length > 0,
    this.languages?.length > 0,
    this.phone
  ];
  
  const mandatoryFields = [
    this.education?.length > 0,
    this.portfolio?.length > 0
  ];
  
  const requiredCompleted = requiredFields.filter(Boolean).length;
  const mandatoryCompleted = mandatoryFields.filter(Boolean).length;
  
  // Can't reach 100% without education and portfolio
  if (mandatoryCompleted < mandatoryFields.length) {
    const maxWithoutMandatory = 85; // Max 85% without education and portfolio
    return Math.min(Math.round((requiredCompleted / requiredFields.length) * maxWithoutMandatory), maxWithoutMandatory);
  }
  
  // All fields including mandatory ones
  const allFields = [...requiredFields, ...mandatoryFields];
  const allCompleted = allFields.filter(Boolean).length;
  return Math.round((allCompleted / allFields.length) * 100);
};

// Reset weekly profile views (call this weekly)
userSchema.methods.resetWeeklyViews = function () {
  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  if (this.lastViewsReset < oneWeekAgo) {
    this.weeklyProfileViews = 0;
    this.lastViewsReset = new Date();
    return this.save();
  }
};

// Increment profile views
userSchema.methods.incrementViews = function () {
  this.profileViews += 1;
  this.weeklyProfileViews += 1;
  return this.save();
};

module.exports = mongoose.model('User', userSchema);